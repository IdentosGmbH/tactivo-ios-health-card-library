var searchData=
[
  ['identifier',['identifier',['../interface_p_b_provider.html#a49e9ebd3720d67319019e5a3da92ebf8',1,'PBProvider']]],
  ['initwithsmartcard_3a',['initWithSmartcard:',['../interface_p_b_health_card_controller.html#a088e0678d8f140063a877db604368cf7',1,'PBHealthCardController']]],
  ['inpatientarea',['inpatientArea',['../interface_p_b_reimbursement.html#a8138dbe20580b84ffa08925d8895f6ab',1,'PBReimbursement']]],
  ['insurancedata',['insuranceData',['../interface_p_b_health_card.html#a24f5000669d2bc712674eaf28e663a39',1,'PBHealthCard']]],
  ['insurantid',['insurantId',['../interface_p_b_personal_data.html#a8e39f82aedd06c5de57d6aed170c675c',1,'PBPersonalData']]],
  ['insuranttype',['insurantType',['../interface_p_b_insurance_data.html#a812e798ce9a21f4dab922afcd00daff5',1,'PBInsuranceData']]]
];
