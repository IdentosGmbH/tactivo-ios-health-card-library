var searchData=
[
  ['addition',['addition',['../interface_p_b_address.html#a2078a535c17a80ebfd0c93c4d6011f6f',1,'PBAddress']]],
  ['authorizedservices',['authorizedServices',['../interface_p_b_reimbursement.html#af13e099eea4f656a3a75ad91b62c335d',1,'PBReimbursement']]]
];
