var searchData=
[
  ['city',['city',['../interface_p_b_address.html#a0264dfc7855f11b0c5a684809f68ad41',1,'PBAddress']]],
  ['countrycode',['countryCode',['../interface_p_b_address.html#af739d9653b02c566ee2a8d8951be08a8',1,'PBAddress::countryCode()'],['../interface_p_b_provider.html#a317502675c62695f6cdf1039e1cf1aca',1,'PBProvider::countryCode()']]]
];
